<?php
/*
    File: services.php
    Author: Isaac Crft
    Date: February 14, 2026
    Description: Services page for T's Travel - details on cruises, all-inclusive, 
                 group travel, and custom planning.
                 Converted from services.html to PHP so the entire site is PHP.
    AI help: Received assistance structuring the repeated service sections cleanly, 
             improving spacing in the "What's Included" card grid, and refining overall page flow.
             Updated: Converted to PHP, added Google Fonts performance fix.
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="T's Travel Services - Cruises, All-Inclusive Vacations, Group Travel, and Custom Trip Planning">
    <title>Our Services - T's Travel</title>
    
    <!-- Google Fonts -->
    <!-- Preconnect to Google Fonts servers to reduce DNS lookup time -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!--
        display=swap tells the browser to render text in a fallback font immediately
        while Playfair Display and Lato load in the background.
    -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    
    <!-- Main stylesheet -->
    <link rel="stylesheet" href="css/style.css?v=2">
</head>
<body>

    <!-- Navigation -->
    <nav class="navbar">
        <a href="index.php" class="logo">
            <div class="logo-icon" aria-hidden="true">✈️</div>
            <span>T's Travel</span>
        </a>
        <div class="hamburger" aria-label="Toggle navigation menu" role="button" tabindex="0">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div class="nav-links">
            <a href="index.php" class="nav-link">Home</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="services.php" class="nav-link active">Services</a>
            <a href="destinations.php" class="nav-link">Destinations</a>
            <a href="contact.php" class="contact-btn">Contact Us</a>
        </div>
    </nav>

    <!-- Hero section -->
    <header class="hero">
        <div class="hero-content">
            <h1>Our Travel Services</h1>
            <p>Expert planning for every type of journey</p>
        </div>
    </header>

    <main>
        <!-- Services list -->
        <section class="content-section">
            <!-- Cruise Vacations -->
            <article class="service-category">
                <div class="service-header">
                    <div class="service-icon-large" aria-hidden="true">🚢</div>
                    <div>
                        <h2>Cruise Vacations</h2>
                    </div>
                </div>
                <p class="service-description">Discover the world from the comfort of a luxury cruise ship. Whether you're dreaming of tropical Caribbean waters, Mediterranean coastlines, or Alaskan glaciers, we'll help you find the perfect cruise experience.</p>
                <div class="service-details">
                    <div class="service-feature">
                        <h3>Ocean Cruises</h3>
                        <p>Caribbean, Mediterranean, Alaska, and worldwide destinations</p>
                    </div>
                    <div class="service-feature">
                        <h3>River Cruises</h3>
                        <p>Intimate journeys through Europe, Asia, and beyond</p>
                    </div>
                    <div class="service-feature">
                        <h3>Specialty Cruises</h3>
                        <p>Themed cruises, expedition cruises, and luxury experiences</p>
                    </div>
                </div>
            </article>

            <!-- All-Inclusive Vacations -->
            <article class="service-category">
                <div class="service-header">
                    <div class="service-icon-large" aria-hidden="true">🏖️</div>
                    <div>
                        <h2>All-Inclusive Vacations</h2>
                    </div>
                </div>
                <p class="service-description">Enjoy complete relaxation with all-inclusive resort packages where everything is taken care of. From meals and drinks to activities and entertainment, simply unwind and enjoy.</p>
                <div class="service-details">
                    <div class="service-feature">
                        <h3>Beach Resorts</h3>
                        <p>Stunning coastal properties in the Caribbean, Mexico, and beyond</p>
                    </div>
                    <div class="service-feature">
                        <h3>Family Resorts</h3>
                        <p>Kid-friendly amenities, activities, and entertainment for all ages</p>
                    </div>
                    <div class="service-feature">
                        <h3>Adults-Only Retreats</h3>
                        <p>Peaceful, sophisticated escapes perfect for couples and adults</p>
                    </div>
                </div>
            </article>

            <!-- Group Travel -->
            <article class="service-category">
                <div class="service-header">
                    <div class="service-icon-large" aria-hidden="true">👥</div>
                    <div>
                        <h2>Group Travel</h2>
                    </div>
                </div>
                <p class="service-description">Traveling with family, friends, or colleagues? We specialize in coordinating group trips that keep everyone together while meeting individual needs and preferences.</p>
                <div class="service-details">
                    <div class="service-feature">
                        <h3>Family Reunions</h3>
                        <p>Multi-generational trips with activities for everyone</p>
                    </div>
                    <div class="service-feature">
                        <h3>Corporate Travel</h3>
                        <p>Team building trips and business group accommodations</p>
                    </div>
                    <div class="service-feature">
                        <h3>Special Celebrations</h3>
                        <p>Destination weddings, anniversaries, and milestone events</p>
                    </div>
                </div>
            </article>

            <!-- Custom Trip Planning -->
            <article class="service-category">
                <div class="service-header">
                    <div class="service-icon-large" aria-hidden="true">✨</div>
                    <div>
                        <h2>Custom Trip Planning</h2>
                    </div>
                </div>
                <p class="service-description">Have a unique vision for your perfect vacation? We create completely customized itineraries tailored to your interests, budget, and travel style.</p>
                <div class="service-details">
                    <div class="service-feature">
                        <h3>Custom Itineraries</h3>
                        <p>Personalized day-by-day plans designed around your preferences</p>
                    </div>
                    <div class="service-feature">
                        <h3>Special Interests</h3>
                        <p>Food tours, adventure travel, cultural experiences, and more</p>
                    </div>
                    <div class="service-feature">
                        <h3>Multi-Destination</h3>
                        <p>Complex trips combining multiple cities, countries, or continents</p>
                    </div>
                </div>
            </article>
        </section>

        <!-- What's Included section -->
        <section class="content-section" style="background: var(--warm-sand); text-align: center;">
            <h2 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; color: var(--primary-blue); margin-bottom: 20px;">What's Included in Every Service</h2>
            <div class="card-grid" style="margin-top: 40px;">
                <article class="card">
                    <div class="card-icon" aria-hidden="true">📋</div>
                    <h3>Personalized Consultation</h3>
                    <p>One-on-one planning sessions to understand your needs</p>
                </article>
                <article class="card">
                    <div class="card-icon" aria-hidden="true">💰</div>
                    <h3>Budget Management</h3>
                    <p>Options and recommendations that fit your budget</p>
                </article>
                <article class="card">
                    <div class="card-icon" aria-hidden="true">📞</div>
                    <h3>Ongoing Support</h3>
                    <p>Available before, during, and after your trip</p>
                </article>
                <article class="card">
                    <div class="card-icon" aria-hidden="true">🎁</div>
                    <h3>Value Added</h3>
                    <p>Access to special amenities and exclusive offers</p>
                </article>
            </div>
        </section>

        <!-- Final call to action -->
        <section class="content-section" style="text-align: center;">
            <h2 style="font-family: 'Playfair Display', serif; font-size: 2.5rem; color: var(--primary-blue); margin-bottom: 20px;">Ready to Get Started?</h2>
            <p style="font-size: 1.2rem; color: var(--text-dark); margin-bottom: 30px; max-width: 700px; margin-left: auto; margin-right: auto;">Let's discuss which service is right for your next adventure. Contact us today for a free consultation.</p>
            <a href="contact.php" class="cta-button">Contact Us</a>
        </section>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <nav class="footer-links" aria-label="Footer navigation">
            <a href="index.php" class="footer-link">Home</a>
            <a href="about.php" class="footer-link">About</a>
            <a href="services.php" class="footer-link">Services</a>
            <a href="destinations.php" class="footer-link">Destinations</a>
            <a href="contact.php" class="footer-link">Contact</a>
        </nav>
        <div class="footer-bottom">
            <p>&copy; 2026 T's Travel. All rights reserved.</p>
            <div class="social-links">
                <a href="#" class="social-link" aria-label="Visit our Facebook page">Facebook</a>
                <a href="#" class="social-link" aria-label="Visit our Instagram page">Instagram</a>
                <a href="#" class="social-link" aria-label="Visit our Twitter page">Twitter</a>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="js/server.js"></script>
</body>
</html>